function [P2]=ERecoverP2(E,B)
    E=uint16(E);
    B=uint16(B);
    P2_B=bitxor(E,B);

    P2=P2_B+256-B;
    P2(P2>=256)=P2((P2>=256))-256;
    P2=uint8(P2);
end