function [x_i2]=PWLCMChaotic(x_i1,eta)
    %PWLCM Chaotic Map
    %x����(0,1)���䣬eta����(0,0.5)����
    if x_i1>0&&x_i1<eta
        x_i2=x_i1/eta;
    elseif x_i1>=eta&&x_i1<0.5
        x_i2=(x_i1-eta)/(2-eta);
    else
        x_i2=PWLCMChaotic(1-x_i1,eta);
    end
%     indx_1=find(x_i1>0&x_i1<eta);
%     x_i2(indx_1)=x_i1(indx_1)./eta;
%     indx_2=find(x_i1>=eta&x_i1<0.5);
%     x_i2(indx_2)=(x_i1(indx_2)-eta)./(2-eta);
%     indx_3=find(x_i1>=0.5&x_i1<1);
%     x_i2(indx_3)=PWLCMChaotic(1-x_i1(indx_3),eta);
end