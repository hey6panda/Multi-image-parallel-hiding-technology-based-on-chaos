function [image_out]=BScrambleP2(P2,B)
    global use_gpu;
    if use_gpu==1
        P2=gpuArray(uint16(P2));
        B=gpuArray(uint16(B));
    end
    P2_B=mod((P2+B),256);               %0-255֮��,P2+B
    image_out=uint8(bitxor(P2_B,B));
    if use_gpu==1
        image_out=gather(image_out);
    end
end