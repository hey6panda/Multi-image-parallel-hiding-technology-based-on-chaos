clear ;
close all;
clc;
%***************************************************


% a=10;b=3/8;c=28;d=-1;
% a=10;b=4;c=1;d=0.5;
A=16.4;B=15;C=0.5;D=1.4;a=0.2;b=0.4;
p=9;n=30;k=1.1;
T=1e-4;%�ɵ�ȡ��ʱ��,T=0.0001
N=2000000;%�ɵ���������
x1=zeros(1,N);
x2=zeros(1,N);
x3=zeros(1,N);
x4=zeros(1,N);
x1(1)=1;x2(1)=1;x3(1)=1;x4(1)=1;
for i=2:N
%     x1(i)=a*T*x2(i-1)+(1-a*T)*x1(i-1)+T*x2(i-1)*x3(i-1)*x4(i-1);
%     x2(i)=c*T*x1(i-1)+(1-T)*x2(i-1)-T*x1(i-1)*x3(i-1)*x4(i-1);
%     x3(i)=(1-b*T)*x3(i-1)+T*x1(i-1)*x2(i-1)*x4(i-1);
%     x4(i)=d*T*x1(i-1)+x4(i-1)+T*x1(i-1)*x2(i-1)*x3(i-1);

%      x1(i)=T*a*x2(i-1)*x3(i-1)-T*x4(i-1)+x1(i-1);
%     x2(i)=T*b*x1(i-1)+(1-T*b)*x2(i-1);
%     x3(i)=c*T-T*x1(i-1)*x2(i-1)+(1-T)*x3(i-1);
%     x4(i)=T*d*x1(i-1)+T*d*x2(i-1)+x4(i-1);

    x1(i)=(1+T*A*D-T*A-T*A*(a+3*b*x4(i-1)*x4(i-1)))*x1(i-1)+T*A*x2(i-1);
    x2(i)=T*x1(i-1)+(1-T)*x2(i-1)+T*x3(i-1);
    x3(i)=-T*B*x2(i-1)+(1-T*C)*x3(i-1);
    x4(i)=T*x1(i-1)+T*k*x3(i-1)+x4(i-1)-T*p*k*( tanh(-n*x3(i-1))+tanh(n*(x3(i-1)+2*p))+tanh(n*x3(i-1))+tanh(n*(x3(i-1)-2*p)) );
%     -tanh(n*x3(i-1))+tanh(n*x3(i-1))+
end
%***************************************************
t=zeros(1,N);
for i=1:N
    t(i)=i;
end
%***************************************************

% subplot(311)

n1=N/2;n2=N;
%{
figure(1)
plot(t(n1:n2),x1(n1:n2),'k-');
xlabel('Tn','fontsize',20,'fontname','times new roman','FontAngle','italic');
ylabel('X1n','fontsize',20,'fontname','times new roman','FontAngle','italic');
figure(2)
plot(t(n1:n2),x2(n1:n2),'k-');
xlabel('Tn','fontsize',20,'fontname','times new roman','FontAngle','italic');
ylabel('X2n','fontsize',20,'fontname','times new roman','FontAngle','italic');
figure(3)
plot(t(n1:n2),x3(n1:n2),'k-');
xlabel('Tn','fontsize',20,'fontname','times new roman','FontAngle','italic');
ylabel('X3n','fontsize',20,'fontname','times new roman','FontAngle','italic');
figure(4)
plot(t(n1:n2),x4(n1:n2),'k-');
xlabel('Tn','fontsize',20,'fontname','times new roman','FontAngle','italic');
ylabel('X4n','fontsize',20,'fontname','times new roman','FontAngle','italic');
%}
% ��ռ�
figure(5)
subplot(2,3,1);plot(x1(n1:n2),x2(n1:n2));
title('(a)','FontSize',15,'fontname','times new roman','FontAngle','italic');
xlabel('x','fontsize',15,'fontname','times new roman','FontAngle','italic');
ylabel('y','fontsize',15,'fontname','times new roman','FontAngle','italic');
% figure(6)
subplot(2,3,2);plot(x1(n1:n2),x3(n1:n2));
title('(b)','FontSize',15,'fontname','times new roman','FontAngle','italic');
xlabel('x','fontsize',15,'fontname','times new roman','FontAngle','italic');
ylabel('z','fontsize',15,'fontname','times new roman','FontAngle','italic');
% figure(7)
subplot(2,3,3);plot(x1(n1:n2),x4(n1:n2));
title('(c)','FontSize',15,'fontname','times new roman','FontAngle','italic');
xlabel('x','fontsize',15,'fontname','times new roman','FontAngle','italic');
ylabel('w','fontsize',15,'fontname','times new roman','FontAngle','italic');
% figure(8)
subplot(2,3,4);plot(x2(n1:n2),x3(n1:n2));
title('(d)','FontSize',15,'fontname','times new roman','FontAngle','italic');
xlabel('y','fontsize',15,'fontname','times new roman','FontAngle','italic');
ylabel('z','fontsize',15,'fontname','times new roman','FontAngle','italic');
% figure(9)
subplot(2,3,5);plot(x2(n1:n2),x4(n1:n2));
title('(e)','FontSize',15,'fontname','times new roman','FontAngle','italic');
xlabel('y','fontsize',15,'fontname','times new roman','FontAngle','italic');
ylabel('w','fontsize',15,'fontname','times new roman','FontAngle','italic');
% figure(10)
subplot(2,3,6);plot(x3(n1:n2),x4(n1:n2))
title('(f)','FontSize',15,'fontname','times new roman','FontAngle','italic');
xlabel('z','fontsize',15,'fontname','times new roman','FontAngle','italic');
ylabel('w','fontsize',15,'fontname','times new roman','FontAngle','italic');
% figure(11)
% plot3(x1(n1:n2),x3(n1:n2),x4(n1:n2),'k-');
% xlabel('X1n','fontsize',20,'fontname','times new roman','FontAngle','italic');
% ylabel('X3n','fontsize',20,'fontname','times new roman','FontAngle','italic');
% zlabel('X4n','fontsize',20,'fontname','times new roman','FontAngle','italic');
% figure(12)
% plot3(x1(n1:n2),x2(n1:n2),x4(n1:n2),'k-');
% xlabel('X1n','fontsize',20,'fontname','times new roman','FontAngle','italic');
% ylabel('X2n','fontsize',20,'fontname','times new roman','FontAngle','italic');
% zlabel('X4n','fontsize',20,'fontname','times new roman','FontAngle','italic');
