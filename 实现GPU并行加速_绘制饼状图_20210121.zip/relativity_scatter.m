function [result]=relativity_scatter(image_in)
    A=image_in;
    [row,col]=size(A);
    %% Horizital
    LH=col/2;                               %����ȡ�����
    I1_Hor=ones(1,LH);I2_Hor=ones(1,LH);    %���ٴ洢����
    for i=1:row
        for j=1:col
            if(mod(j,2)==1)     %odd
                I1_Hor((i-1)*LH+(j+1)/2)=A(i,j);
            end
            if(mod(j,2)==0)     %even
                I2_Hor((i-1)*LH+j/2)=A(i,j);
            end
        end
    end
    scatter(I1_Hor,I1_Hor,'b','filled');
    %% results
    result=1;
end