function [image_out]=BR(image_in,A,m,n)
    global use_gpu;
    if use_gpu==1
        image_in=gpuArray(image_in);
        A=gpuArray(A);
    end
    image_temp=image_in;
    image_temp = bitor( bsxfun(@bitshift,image_temp,8-A),bsxfun(@bitshift,image_temp,-A) );
    image_out=uint8(image_temp);
    if use_gpu==1
        image_out=gather(image_out);
    end
end